# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['gendiff', 'gendiff.scripts', 'gendiff.tests', 'gendiff.tests.fixtures']

package_data = \
{'': ['*']}

install_requires = \
['PyYAML>=6.0,<7.0',
 'coverage>=6.5.0,<7.0.0',
 'flake8>=5.0.4,<6.0.0',
 'pytest-cov>=4.0.0,<5.0.0',
 'pytest>=7.1.3,<8.0.0',
 'yamllint>=1.28.0,<2.0.0']

entry_points = \
{'console_scripts': ['gendiff = gendiff.scripts.gendiff_script:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
